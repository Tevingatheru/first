﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Move : MonoBehaviour
{
    public float move = 50f;
    public float jump = 50f;
    

    public Rigidbody rb;
    // Use this for initialization
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        // transform.Translate(Input.GetAxis("Horizontal")* move * Time.deltaTime,Input.GetAxis("Jump")* jump *Time.deltaTime, Input.GetAxis("Vertical") * move * Time.deltaTime);

        rb.AddForce(Input.GetAxis("Horizontal") * move * Time.deltaTime, 0, 0, ForceMode.VelocityChange);
        rb.AddForce(0, 0, Input.GetAxis("Vertical") * move * Time.deltaTime, ForceMode.Impulse);
      
    }
    void OnCollisionEnter(Collision collision)
    {
        if (collision.collider.tag=="floor") {
            rb.AddForce(0, Input.GetAxis("Jump") * jump * Time.deltaTime, 0, ForceMode.Acceleration);
        }

    }

}
