﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class rotation : MonoBehaviour {
    public Transform target;
    // Use this for initialization
    void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
        // transform.Rotate( 0, 0, Rspeed * speed * Time.deltaTime);
        Vector3 relativePos = target.position  - transform.position;
        transform.rotation = Quaternion.LookRotation(relativePos);
    }
}
